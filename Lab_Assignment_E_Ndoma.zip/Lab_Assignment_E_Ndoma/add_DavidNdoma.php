<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title> Course Management Systems - New Course </title>
</head>
<body>

<?php


/*
Filename: add_course.php
Description: The file will take data from a form and add it to a table created in MySQL database
Author: David Ndoma
Date: November 20, 2023
*/

//Form data will be connected to MYSQL using the following the database information
$servername = "uborujaniii.info";
$username = "Ndoma";
$password = "Selfish2020@";
$dbname = "faculty";

// Create connection
$conn =  new mysqli($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

//Select database
mysqli_select_db ( $conn , $dbname);


// SQL statement to insert form posted data into table:course and store statement in a variable $sql
// the variable parameters on the right are inside the $_POST are received from the form.

$sql = $conn->prepare("INSERT INTO faculty_info (FACULTY_ID, FACULTY_LASTNAME, FACULTY_FIRSTNAME, FACULTY_OFFICE) VALUES (?, ?, ?, ?)");
$sql->bind_param("ssss", $faculty_id, $faculty_lastname, $faculty_firstname, $faculty_office);

$faculty_id = $_POST['faculty_id'];
$faculty_lastname = $_POST['faculty_lastname'];
$faculty_firstname = $_POST['faculty_firstname'];
$faculty_office = $_POST['faculty_office'];
$sql->execute();

// Display confirmation
echo "Your new course has been created. <br>";




$sql -> close();

// Close connection
mysqli_close($conn);
?>
</span>

</body>
</html>